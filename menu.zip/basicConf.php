<?php 
define('SITE_ASSETS','http://localhost/breno/assets');
$logo_url = SITE_ASSETS.'/img/logo.png';
$favicon = SITE_ASSETS.'/img/favicon.png';
define('SITE_URL','http://localhost/breno/');
define('SITE_TITLE','Aarogya Wellness');
define('SITE_LOGO',$logo_url);
define('SITE_FAVICON',$favicon);
define('facebook','');
define('twitter','');
define('instagram','');
define('linkdin','');

