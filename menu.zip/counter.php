<div data-vc-full-width="true" data-vc-full-width-init="false" data-bg-overlay="rgba(0,0,0,0.73)" data-class="breno-custom-row-45" class="vc_row wpb_row vc_row-fluid vc_custom_1554878395450 vc_row-has-fill vc_row-o-content-middle vc_row-flex typo-white row-overlay-custom breno-vc-row breno-custom-row-45">
    <span class="row-overlay"></span>
    <div class="wpb_column vc_column_container vc_col-sm-3 vc_col-lg-3 vc_col-md-6 vc_col-has-fill">
        <div class="vc_column-inner vc_custom_1551074216349">
            <div class="wpb_wrapper">
            <div class="counter-wrapper custom-text-color counter-style-1 text-center shortcode-rand-46 breno-inline-css" data-css="&quot;.shortcode-rand-46.counter-wrapper &gt; *:nth-child(1) { margin-bottom: 30px; }.shortcode-rand-46.counter-wrapper, .shortcode-rand-46.counter-wrapper h3, .shortcode-rand-46.counter-wrapper h4 { color: #476441; }&quot;">
                <div class="counter-thumb"><img class="img-fluid" src="<?php echo SITE_ASSETS;?>/img/client/004-tree-white.png" width="64" height="64" alt="Tree Saved" /></div>
                <div class="counter-value">
                    <h3><span class="counter-up" data-count="20403">0</span><span class="counter-suffix">+</span></h3>
                </div>
                <div class="counter-title">
                    <h4>Tree Saved</h4>
                </div>
            </div>
            </div>
        </div>
    </div>
    <div class="wpb_column vc_column_container vc_col-sm-3 vc_col-lg-3 vc_col-md-6 vc_col-has-fill">
        <div class="vc_column-inner vc_custom_1551074365113">
            <div class="wpb_wrapper">
            <div class="counter-wrapper custom-text-color counter-style-1 text-center shortcode-rand-47 breno-inline-css" data-css="&quot;.shortcode-rand-47.counter-wrapper &gt; *:nth-child(1) { margin-bottom: 30px; }.shortcode-rand-47.counter-wrapper, .shortcode-rand-47.counter-wrapper h3, .shortcode-rand-47.counter-wrapper h4 { color: #476441; }&quot;">
                <div class="counter-thumb"><img class="img-fluid" src="<?php echo SITE_ASSETS;?>/img/client/002-elephant-white.png" width="64" height="64" alt="Animals Saved" /></div>
                <div class="counter-value">
                    <h3><span class="counter-up" data-count="4695">0</span><span class="counter-suffix">+</span></h3>
                </div>
                <div class="counter-title">
                    <h4>Animals Saved</h4>
                </div>
            </div>
            </div>
        </div>
    </div>
    <div class="wpb_column vc_column_container vc_col-sm-3 vc_col-lg-3 vc_col-md-6 vc_col-has-fill">
        <div class="vc_column-inner vc_custom_1551074298680">
            <div class="wpb_wrapper">
            <div class="counter-wrapper custom-text-color counter-style-1 text-center shortcode-rand-48 breno-inline-css" data-css="&quot;.shortcode-rand-48.counter-wrapper &gt; *:nth-child(1) { margin-bottom: 30px; }.shortcode-rand-48.counter-wrapper, .shortcode-rand-48.counter-wrapper h3, .shortcode-rand-48.counter-wrapper h4 { color: #476441; }&quot;">
                <div class="counter-thumb"><img class="img-fluid" src="<?php echo SITE_ASSETS;?>/img/client/003-sunlight.png" width="64" height="64" alt="Solar Installed" /></div>
                <div class="counter-value">
                    <h3><span class="counter-up" data-count="3235">0</span><span class="counter-suffix">+</span></h3>
                </div>
                <div class="counter-title">
                    <h4>Solar Installed</h4>
                </div>
            </div>
            </div>
        </div>
    </div>
    <div class="wpb_column vc_column_container vc_col-sm-3 vc_col-lg-3 vc_col-md-6">
        <div class="vc_column-inner">
            <div class="wpb_wrapper">
            <div class="counter-wrapper custom-text-color counter-style-1 text-center shortcode-rand-49 breno-inline-css" data-css="&quot;.shortcode-rand-49.counter-wrapper &gt; *:nth-child(1) { margin-bottom: 30px; }.shortcode-rand-49.counter-wrapper, .shortcode-rand-49.counter-wrapper h3, .shortcode-rand-49.counter-wrapper h4 { color: #476441; }&quot;">
                <div class="counter-thumb"><img class="img-fluid" src="<?php echo SITE_ASSETS;?>/img/client/003-water-white.png" width="64" height="64" alt="Water Resources" /></div>
                <div class="counter-value">
                    <h3><span class="counter-up" data-count="6452">0</span><span class="counter-suffix">+</span></h3>
                </div>
                <div class="counter-title">
                    <h4>Water Resources</h4>
                </div>
            </div>
            </div>
        </div>
    </div>
</div>
<div class="vc_row-full-width vc_clearfix"></div>