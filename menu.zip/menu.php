<header class="breno-header">
            <div class="header-inner hidden-md-down hidden-md-land-down">
               
               <div class="sticky-outer1">
                  <div class="sticky-head">
                     <nav class="navbar clearfix">
                        <div class="custom-container navbar-inner">
                        <div class="main-logo pull-left"> <a href="<?php echo SITE_URL;?>/" title="Breno" ><img class="custom-logo img-responsive" src="<?php echo SITE_LOGO;?>" alt="Aarogya Wellness" title="Aarogya Wellness" /></a></div>
                           <ul class="navbar-items nav pull-right">
                              <li class="nav-item">
                                 <div class="nav-item-inner">
                                    <ul id="breno-main-menu" class="nav breno-main-menu">
                                       <li id="menu-item-5768" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home current-menu-item page_item page-item-5670 current_page_item menu-item-has-children nav-item menu-item-5768 dropdown">
                                          <a href="index.html" class="nav-link">Home</a>
                                       </li>
                                       <li id="menu-item-5630" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children nav-item menu-item-5630 dropdown">
                                          <a href="<?php echo SITE_URL;?>/about.php" class="nav-link">About</a>
                                          
                                       </li>
                                       <li id="menu-item-4961" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children nav-item menu-item-4961 dropdown">
                                          <a href="<?php echo SITE_URL;?>/products.php" class="nav-link dropdown-toggle">Products</a>
                                          <ul role="menu" class=" dropdown-menu">
                                             <li id="menu-item-5789" class="menu-item menu-item-type-post_type menu-item-object-page nav-item menu-item-5789"><a href="<?php echo SITE_URL;?>/ipluse.php" class="nav-link">iPulse</a></li>
                                             <li id="menu-item-4933" class="menu-item menu-item-type-post_type menu-item-object-breno-service nav-item menu-item-4933"><a href="<?php echo SITE_URL;?>/icoffee.php" class="nav-link">iCoffee</a></li>
                                             <li id="menu-item-4934" class="menu-item menu-item-type-post_type menu-item-object-breno-service nav-item menu-item-4934"><a href="<?php echo SITE_URL;?>/islim.php" class="nav-link">iSlim</a></li>
                                             <li id="menu-item-4935" class="menu-item menu-item-type-post_type menu-item-object-breno-service nav-item menu-item-4935"><a href="<?php echo SITE_URL;?>/iglow.php" class="nav-link">iGlow</a></li>
                                             <li id="menu-item-4936" class="menu-item menu-item-type-post_type menu-item-object-breno-service nav-item menu-item-4936"><a href="<?php echo SITE_URL;?>/icare.php" class="nav-link">iCare</a></li>
                                          </ul>
                                       </li>
                                       <li id="menu-item-5788" class="menu-item menu-item-type-post_type menu-item-object-page nav-item menu-item-5788"><a href="<?php echo SITE_URL;?>/contact-us.php" class="nav-link">Contact us</a></li>
                                    </ul>
                                 </div>
                              </li>
                           </ul>
                           
                        </div>
                     </nav>
                  </div>
               </div>
            </div>
         </header>