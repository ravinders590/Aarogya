<div data-vc-full-width="true" data-vc-full-width-init="false" class="vc_row wpb_row vc_row-fluid vc_custom_1554878563921 vc_row-has-fill">
    <div class="wpb_column vc_column_container vc_col-sm-12">
        <div class="vc_column-inner">
            <div class="wpb_wrapper">
            <div class="vc_row wpb_row vc_inner vc_row-fluid">
                <div class="wpb_column vc_column_container vc_col-sm-12">
                    <div class="vc_column-inner">
                        <div class="wpb_wrapper">
                        <div class="section-title-wrapper text-center shortcode-rand-53 breno-inline-css" data-css="&quot;.shortcode-rand-53 .background-title { font-family:Dancing Script;font-weight:700;font-style:normal }.shortcode-rand-53 .background-title { color: #f0f0f0; }.shortcode-rand-53 .title-separator.separator-border,.section-title-wrapper .title-separator.separator-border:after, .section-title-wrapper .title-separator.separator-border:before { background-color: ; }.shortcode-rand-53.section-title-wrapper .sub-title { color: #eb2f5b; }.shortcode-rand-53 .section-title { text-transform: none; }&quot;">
                            <div class="title-wrap bg-title-enabled">
                                <h2 class="section-title">What We Offer</h2>
                                <span class="title-separator separator-border theme-color-bg"></span>
                            </div>
                            <div class="section-description">Mauris id enim id purus ornare tincidunt. Aenean vel consequat risus. Proin viverra nisi at nisl imperdiet auctor. Donec ornare, est sed tincidunt placerat.</div>
                            <div class="button-section"></div>
                        </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="vc_row wpb_row vc_inner vc_row-fluid offer-us">
                <div class="wpb_column vc_column_container vc_col-sm-12 vc_col-lg-4 vc_col-md-12">
                    <div class="vc_column-inner">
                        <div class="wpb_wrapper">
                        <div class="feature-box-wrapper feature-box-style-2 text-left vc_custom_1554878408782 shortcode-rand-54 breno-inline-css feature-list-1" data-css="&quot;.shortcode-rand-54.feature-box-wrapper .section-title { color: #151515; }.shortcode-rand-54.feature-box-wrapper .fbox-list .media-body &gt; *:nth-child(1) { margin-bottom: 20px; }.shortcode-rand-54.feature-box-wrapper .fbox-list .media-body &gt; *:nth-child(2) { margin-bottom: 0px; }.shortcode-rand-54.feature-box-wrapper {background: -moz-linear-gradient(141deg,  0%,  51%,  75%);\r\n\t\t\t\tbackground: -webkit-linear-gradient(141deg,  0%,  51%,  75%);\r\n\t\t\t\tbackground: linear-gradient(141deg,  0%,  51%,  75%);}.shortcode-rand-54 .feature-box-icon { font-size: 50px; }.shortcode-rand-54:hover .feature-box-icon { color: #8e8e8e; }&quot;" >
                            <div class="fbox-list">
                                <div class="media">
                                    <div class="feature-box-thumb mr-4"><img class="img-fluid squared" src="<?php echo SITE_ASSETS;?>/img/offer/philosophy.png" width="64" height="64" alt="Wind Energy" /></div>
                                    <div class="media-body">
                                    <div class="feature-box-title">
                                        <h5 class="section-title">Our Philosophy</h5>
                                    </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="feature-box-wrapper feature-box-style-2 text-left vc_custom_1554878419038 shortcode-rand-55 breno-inline-css feature-list-1" data-css="&quot;.shortcode-rand-55.feature-box-wrapper .section-title { color: #151515; }.shortcode-rand-55.feature-box-wrapper .fbox-list .media-body &gt; *:nth-child(1) { margin-bottom: 20px; }.shortcode-rand-55.feature-box-wrapper .fbox-list .media-body &gt; *:nth-child(2) { margin-bottom: 0px; }.shortcode-rand-55.feature-box-wrapper {background: -moz-linear-gradient(141deg,  0%,  51%,  75%);\r\n\t\t\t\tbackground: -webkit-linear-gradient(141deg,  0%,  51%,  75%);\r\n\t\t\t\tbackground: linear-gradient(141deg,  0%,  51%,  75%);}.shortcode-rand-55 .feature-box-icon { font-size: 50px; }.shortcode-rand-55:hover .feature-box-icon { color: #8e8e8e; }&quot;" >
                            <div class="fbox-list">
                                <div class="media">
                                    <div class="feature-box-thumb mr-4"><img class="img-fluid squared" src="<?php echo SITE_ASSETS;?>/img/offer/objective.png" width="64" height="64" alt="Solar Energy" /></div>
                                    <div class="media-body">
                                    <div class="feature-box-title">
                                        <h5 class="section-title">Our Objectives</h5>
                                    </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        </div>
                    </div>
                </div>
                <div class="wpb_column vc_column_container vc_col-sm-12 vc_col-lg-4 vc_col-md-12">
                    <div class="vc_column-inner">
                        <div class="wpb_wrapper">
                        <div class="feature-box-wrapper feature-box-style-2 text-left vc_custom_1554878427668 shortcode-rand-56 breno-inline-css feature-list-1" data-css="&quot;.shortcode-rand-56.feature-box-wrapper .section-title { color: #151515; }.shortcode-rand-56.feature-box-wrapper .fbox-list .media-body &gt; *:nth-child(1) { margin-bottom: 20px; }.shortcode-rand-56.feature-box-wrapper .fbox-list .media-body &gt; *:nth-child(2) { margin-bottom: 0px; }.shortcode-rand-56.feature-box-wrapper {background: -moz-linear-gradient(141deg,  0%,  51%,  75%);\r\n\t\t\t\tbackground: -webkit-linear-gradient(141deg,  0%,  51%,  75%);\r\n\t\t\t\tbackground: linear-gradient(141deg,  0%,  51%,  75%);}.shortcode-rand-56 .feature-box-icon { font-size: 50px; }.shortcode-rand-56:hover .feature-box-icon { color: #8e8e8e; }&quot;" >
                            <div class="fbox-list">
                                <div class="media">
                                    <div class="feature-box-thumb mr-4"><img class="img-fluid squared" src="<?php echo SITE_ASSETS;?>/img/offer/our-choice.png" width="64" height="64" alt="Renewable Energy" /></div>
                                    <div class="media-body">
                                    <div class="feature-box-title">
                                        <h5 class="section-title">Your Choice</h5>
                                    </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="feature-box-wrapper feature-box-style-2 text-left vc_custom_1554878436388 shortcode-rand-57 breno-inline-css feature-list-1" data-css="&quot;.shortcode-rand-57.feature-box-wrapper .section-title { color: #151515; }.shortcode-rand-57.feature-box-wrapper .fbox-list .media-body &gt; *:nth-child(1) { margin-bottom: 20px; }.shortcode-rand-57.feature-box-wrapper .fbox-list .media-body &gt; *:nth-child(2) { margin-bottom: 0px; }.shortcode-rand-57.feature-box-wrapper {background: -moz-linear-gradient(141deg,  0%,  51%,  75%);\r\n\t\t\t\tbackground: -webkit-linear-gradient(141deg,  0%,  51%,  75%);\r\n\t\t\t\tbackground: linear-gradient(141deg,  0%,  51%,  75%);}.shortcode-rand-57 .feature-box-icon { font-size: 50px; }.shortcode-rand-57:hover .feature-box-icon { color: #8e8e8e; }&quot;" >
                            <div class="fbox-list">
                                <div class="media">
                                    <div class="feature-box-thumb mr-4"><img class="img-fluid squared" src="<?php echo SITE_ASSETS;?>/img/offer/vision.png" width="64" height="64" alt="Energy Saving" /></div>
                                    <div class="media-body">
                                    <div class="feature-box-title">
                                        <h5 class="section-title">Our Vision</h5>
                                    </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        </div>
                    </div>
                </div>
                <div class="wpb_column vc_column_container vc_col-sm-12 vc_col-lg-4 vc_col-md-12">
                    <div class="vc_column-inner">
                        <div class="wpb_wrapper">
                        <div class="feature-box-wrapper feature-box-style-2 text-left vc_custom_1554878447761 shortcode-rand-58 breno-inline-css feature-list-1" data-css="&quot;.shortcode-rand-58.feature-box-wrapper .section-title { color: #151515; }.shortcode-rand-58.feature-box-wrapper .fbox-list .media-body &gt; *:nth-child(1) { margin-bottom: 20px; }.shortcode-rand-58.feature-box-wrapper .fbox-list .media-body &gt; *:nth-child(2) { margin-bottom: 0px; }.shortcode-rand-58.feature-box-wrapper {background: -moz-linear-gradient(141deg,  0%,  51%,  75%);\r\n\t\t\t\tbackground: -webkit-linear-gradient(141deg,  0%,  51%,  75%);\r\n\t\t\t\tbackground: linear-gradient(141deg,  0%,  51%,  75%);}.shortcode-rand-58 .feature-box-icon { font-size: 50px; }.shortcode-rand-58:hover .feature-box-icon { color: #8e8e8e; }&quot;" >
                            <div class="fbox-list">
                                <div class="media">
                                    <div class="feature-box-thumb mr-4"><img class="img-fluid squared" src="<?php echo SITE_ASSETS;?>/img/offer/target.png" width="64" height="64" alt="Solar Energy" /></div>
                                    <div class="media-body">
                                    <div class="feature-box-title">
                                        <h5 class="section-title">Our Mision</h5>
                                    </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="feature-box-wrapper feature-box-style-2 text-left vc_custom_1554878456428 shortcode-rand-59 breno-inline-css feature-list-1" data-css="&quot;.shortcode-rand-59.feature-box-wrapper .section-title { color: #151515; }.shortcode-rand-59.feature-box-wrapper .fbox-list .media-body &gt; *:nth-child(1) { margin-bottom: 20px; }.shortcode-rand-59.feature-box-wrapper .fbox-list .media-body &gt; *:nth-child(2) { margin-bottom: 0px; }.shortcode-rand-59.feature-box-wrapper {background: -moz-linear-gradient(141deg,  0%,  51%,  75%);\r\n\t\t\t\tbackground: -webkit-linear-gradient(141deg,  0%,  51%,  75%);\r\n\t\t\t\tbackground: linear-gradient(141deg,  0%,  51%,  75%);}.shortcode-rand-59 .feature-box-icon { font-size: 50px; }.shortcode-rand-59:hover .feature-box-icon { color: #8e8e8e; }&quot;" >
                            <div class="fbox-list">
                                <div class="media">
                                    <div class="feature-box-thumb mr-4"><img class="img-fluid squared" src="<?php echo SITE_ASSETS;?>/img/offer/opportunity.png" width="64" height="64" alt="Green Technology" /></div>
                                    <div class="media-body">
                                    <div class="feature-box-title">
                                        <h5 class="section-title">Viva Choice</h5>
                                    </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        </div>
                    </div>
                </div>
            </div>
            </div>
        </div>
    </div>
</div>
<div class="vc_row-full-width vc_clearfix"></div>