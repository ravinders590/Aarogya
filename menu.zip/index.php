<?php include_once 'header.php';?>
      <div id="page" class="breno-wrapper">
      <?php include_once 'menu.php';?>
         <div class="breno-content-wrapper">
            <div class="breno-content breno-page">
               <?php include_once 'slider.php';?>
               <div class="breno-content-inner">
                  <div class="container">
                     <div class="row">
                        <div class="col-md-12 page-has-no-sidebar">
                           <div id="primary" class="content-area clearfix">
                              <div id="page-5670" class="post-5670 page type-page status-publish hentry">
                                 <div class="entry-content">
                                    <?php include_once 'banner_bottom_cards.php';?>
                                    <?php include_once 'intro.php' ?>
                                    <?php include_once 'counter.php' ?>
                                    <?php include_once 'our_products.php' ?>
                                    <?php include_once 'offer.php' ?>
                                    <?php include_once 'testimonial.php' ?>
                                    
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <?php include_once 'get_in_touch.php' ?>
               </div>
            </div>
         </div>
         <?php include_once 'footer_menu.php';?>
      </div>
<?php include_once 'footer.php';?>