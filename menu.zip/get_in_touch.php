<section class="get-in-touch-wrapper">
    <div class="container p-relative">
        <div class="row">
            <div class="col-md-6">
                <div class="get-in-touch-title">
                    <h3>We will available for help 24X7</h3>
                </div>
            </div>
            <div class="col-md-6">
                <div class="contact-us text-right">
                    <a href="<?php echo SITE_URL;?>/contact-us.php" class="btn btn-primary contact-btn">Contact us</a>
                </div>
            </div>
        </div>
    </div>
</section>