<div data-vc-full-width="true" data-vc-full-width-init="false" class="vc_row wpb_row vc_row-fluid overflow-visible vc_custom_1553855819935 vc_row-has-fill" style="background-image: url(<?php echo SITE_ASSETS;?>/img/bg_2.jpg?id=5727)">
    <div class="wpb_column vc_column_container vc_col-sm-6 vc_col-lg-5 vc_col-md-6">
        <div class="vc_column-inner">
            <div class="wpb_wrapper">
            <div class="vc_row wpb_row vc_inner vc_row-fluid vc_custom_1553846738555 vc_row-has-fill">
                <div class="wpb_column vc_column_container vc_col-sm-12 vc_col-has-fill">
                    <div class="vc_column-inner vc_custom_1553847089158">
                        <div class="wpb_wrapper">
                        <div class="section-title-wrapper text-left shortcode-rand-64 breno-inline-css" data-css="&quot;.shortcode-rand-64 .background-title { font-family:Dancing Script;font-weight:700;font-style:normal }.shortcode-rand-64 .background-title { color: #f0f0f0; }.shortcode-rand-64 .title-separator.separator-border,.section-title-wrapper .title-separator.separator-border:after, .section-title-wrapper .title-separator.separator-border:before { background-color: ; }.shortcode-rand-64.section-title-wrapper { color: #ffffff; }.shortcode-rand-64.section-title-wrapper .sub-title { color: #000000; }.shortcode-rand-64.section-title-wrapper &gt; *:nth-child(1) { margin-bottom: 25px; }.shortcode-rand-64.section-title-wrapper &gt; *:nth-child(2) { margin-bottom: 20px; }.shortcode-rand-64 .section-title { color: #ffffff; text-transform: none; }&quot;">
                            <div class="title-wrap bg-title-enabled">
                                <h2 class="section-title">Testimonials</h2>
                                <span class="title-separator separator-border theme-color-bg"></span>
                            </div>
                            <div class="section-description"></div>
                            <div class="button-section"></div>
                        </div>
                        <div class="testimonial-wrapper testimonial-2 text-left testimonial-light shortcode-rand-65 breno-inline-css" data-css="&quot;.shortcode-rand-65.testimonial-wrapper .testimonial-inner &gt; *:nth-child(1) { margin-bottom: 24px; }.shortcode-rand-65.testimonial-wrapper .testimonial-inner &gt; *:nth-child(2) { margin-bottom: 25px; }&quot;">
                            <div class="row">
                                <div class="breno-page-carousel owl-carousel" data-loop="1" data-margin="35" data-center="0" data-nav="0" data-dots="1" data-autoplay="0" data-items="1" data-items-tab="1" data-items-mob="1" data-duration="5000" data-smartspeed="250" data-scrollby="1" data-autoheight="false">
                                    <div class="item">
                                    <div class="col-lg-12 col-md-12">
                                        <div class="testimonial-inner rounded">
                                            <div class="testimonial-thumb"><img width="80" height="80" src="<?php echo SITE_ASSETS;?>/img/testimonial/tets-4-80x80.jpg" class="img-fluid rounded-circle wp-post-image" alt="" loading="lazy" srcset="<?php echo SITE_ASSETS;?>/img/testimonial/tets-4-80x80.jpg 80w, <?php echo SITE_ASSETS;?>/img/testimonial/tets-4-100x100.jpg 100w, <?php echo SITE_ASSETS;?>/img/testimonial/tets-4.jpg 300w" sizes="(max-width: 80px) 100vw, 80px" /></div>
                                            <div class="testimonial-info">
                                                <p><a href="<?php echo SITE_URL;?>" class="client-name">Johny</a><span class="client-designation">Manager</span></p>
                                            </div>
                                            <div class="testimonial-excerpt">
                                                <p>Mauris id enim id purus ornare tincidunt. Aenean vel consequat risus. Proin viverra nisi at nisl imperdiet auctor. Donec ornare,</p>
                                            </div>
                                        </div>
                                    </div>
                                    </div>
                                    <div class="item">
                                    <div class="col-lg-12 col-md-12">
                                        <div class="testimonial-inner rounded">
                                            <div class="testimonial-thumb"><img width="80" height="80" src="<?php echo SITE_ASSETS;?>/img/testimonial/test-2-80x80.jpg" class="img-fluid rounded-circle wp-post-image" alt="" loading="lazy" srcset="<?php echo SITE_ASSETS;?>/img/testimonial/test-2-80x80.jpg 80w, <?php echo SITE_ASSETS;?>/img/testimonial/test-2.jpg 260w, <?php echo SITE_ASSETS;?>/img/testimonial/test-2-100x100.jpg 100w" sizes="(max-width: 80px) 100vw, 80px" /></div>
                                            <div class="testimonial-info">
                                                <p><a href="<?php echo SITE_URL;?>" class="client-name">Mahufuz Riad</a><span class="client-designation">CEO</span></p>
                                            </div>
                                            <div class="testimonial-excerpt">
                                                <p>Mauris id enim id purus ornare tincidunt. Aenean vel consequat risus. Proin viverra nisi at nisl imperdiet auctor. Donec ornare,</p>
                                            </div>
                                        </div>
                                    </div>
                                    </div>
                                    <div class="item">
                                    <div class="col-lg-12 col-md-12">
                                        <div class="testimonial-inner rounded">
                                            <div class="testimonial-thumb"><img width="80" height="80" src="<?php echo SITE_ASSETS;?>/img/testimonial/test-1-80x80.jpg" class="img-fluid rounded-circle wp-post-image" alt="" loading="lazy" srcset="<?php echo SITE_ASSETS;?>/img/testimonial/test-1-80x80.jpg 80w, <?php echo SITE_ASSETS;?>/img/testimonial/test-1-300x300.jpg 300w, <?php echo SITE_ASSETS;?>/img/testimonial/test-1-100x100.jpg 100w, <?php echo SITE_ASSETS;?>/img/testimonial/test-1.jpg 500w" sizes="(max-width: 80px) 100vw, 80px" /></div>
                                            <div class="testimonial-info">
                                                <p><a href="<?php echo SITE_URL;?>" class="client-name">John Doe</a><span class="client-designation">CEO</span></p>
                                            </div>
                                            <div class="testimonial-excerpt">
                                                <p>Mauris id enim id purus ornare tincidunt. Aenean vel consequat risus. Proin viverra nisi at nisl imperdiet auctor. Donec ornare,</p>
                                            </div>
                                        </div>
                                    </div>
                                    </div>
                                    <div class="item">
                                    <div class="col-lg-12 col-md-12">
                                        <div class="testimonial-inner rounded">
                                            <div class="testimonial-thumb"><img width="80" height="80" src="<?php echo SITE_ASSETS;?>/img/testimonial/test-3-80x80.jpg" class="img-fluid rounded-circle wp-post-image" alt="" loading="lazy" srcset="<?php echo SITE_ASSETS;?>/img/testimonial/test-3-80x80.jpg 80w, <?php echo SITE_ASSETS;?>/img/testimonial/test-3.jpg 260w, <?php echo SITE_ASSETS;?>/img/testimonial/test-3-100x100.jpg 100w" sizes="(max-width: 80px) 100vw, 80px" /></div>
                                            <div class="testimonial-info">
                                                <p><a href="<?php echo SITE_URL;?>" class="client-name">Angelina</a><span class="client-designation">Analytics</span></p>
                                            </div>
                                            <div class="testimonial-excerpt">
                                                <p>Mauris id enim id purus ornare tincidunt. Aenean vel consequat risus. Proin viverra nisi at nisl imperdiet auctor. Donec ornare,</p>
                                            </div>
                                        </div>
                                    </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        </div>
                    </div>
                </div>
            </div>
            </div>
        </div>
    </div>
    <div class="wpb_column vc_column_container vc_col-sm-6 vc_col-lg-7 vc_col-md-6">
        <div class="vc_column-inner">
            <div class="wpb_wrapper"></div>
        </div>
    </div>
</div>
<div class="vc_row-full-width vc_clearfix"></div>